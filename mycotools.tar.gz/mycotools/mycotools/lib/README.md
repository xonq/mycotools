Default python libraries for Mycotools and MycotoolsDB
